﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibreriaOnline
{
    public class CADRecomendaciones
    {
        public bool addRecomendado(ENURecomendaciones lista)
        {
            //Actualiza la lista de recomendados de un usuario, al añadir un libro

            return false;
        }

        public bool removeRecomendado(ENURecomendaciones lista)
        {
            //Actualiza la lista de recomendados de un usuario, al eliminar un libro

            return false;
        }

        
    }
}
