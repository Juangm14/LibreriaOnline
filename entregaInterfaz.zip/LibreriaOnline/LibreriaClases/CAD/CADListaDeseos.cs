﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibreriaOnline
{
    public class CADListaDeseos
    {
        public bool addDeseado(ENUListaDeseos auxiliar)
        {
            //Actualiza la lista de deseados de un usuario y añade el libro correspondiente
            return false;
        }

        public bool removeDeseado(ENUListaDeseos auxiliar)
        {
            //Comprueba que libros deseados tiene un usuario y si este no esta lo elimina
            return false;
        }
    }
}

