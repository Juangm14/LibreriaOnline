﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD
{
    public class CADproveedores
    {
        public bool LicenciaProveedores()
        {
            return true;
        }
        public bool AdministraLibros()
        {
            return true;
        }
    }
}
