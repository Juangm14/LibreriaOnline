﻿using LibreriaOnline.EN;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD
{
	public class CADSoporte
	{
		private String constring;

			public CADSoporte()
			{

			}

			public bool readPregunta(ENSoporte soporte)
			{
				return true;
			}
			public bool readFirstPregunta(ENSoporte soporte)
			{
				return true;
			}

		public bool createPregunta(ENSoporte soporte)
			{
				return true;
			}
			public bool readFirtPregunta(ENSoporte soporte)
			{
				return true;
			}
			public bool readNextPregunta(ENSoporte soporte)
			{
				return true;
			}
			public bool readPrevPregunta(ENSoporte soporte)
			{
				return true;

			}
			public bool editPregunta(ENSoporte soporte)
			{
				return true;
			}
			public bool deletePregunta(ENSoporte soporte)
			{
				return true;
			}
		}
	}


