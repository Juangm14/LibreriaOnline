﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD
{
    class CADlibros
    {
        public CADlibros()
        {

        }

        public bool createLibros(ENlibros en)
        {
            return true;
        }

        public bool deleteLibros(ENlibros en)
        {
            return true;
        }

        public bool updatelibros(ENlibros en)
        {
            return true;
        }

        public bool adminLibros(ENlibros en)
        {
            return true;
        }

        public bool ColeccionLibros(ENlibros en)
        {
            return true;
        }

        public bool CriticaLibros(ENlibros en)
        {
            return true;
        }

        public bool CompraLibros(ENlibros en)
        {
            return true;
        }
        public bool NotaLibros(ENlibros en)
        {
            return true;
        }

        public RecomiendaLibros(ENlibros en)
        {
            return true;
        }
        public relUsuarioLibros(ENlibros en)
        {
            return true;
        }
    }
}
