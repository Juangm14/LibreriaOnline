﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD
{
    class CADSugerencias
    {
        private ArrayList sugerencias = new ArrayList();
        private string constring;


        public CAD_Sugerencias{

        }


    public bool createSugerencia(ENSugerencias en)
    {
        return true;
    }

    public bool readSugerencia(ENSugerencias en)
    {
        return true;
    }

    public bool updateSugerencia(ENSugerencias en)
    {
        return true;
    }

    public bool deleteSugerencia(ENSugerencias en)
    {
        return true;
    }
}