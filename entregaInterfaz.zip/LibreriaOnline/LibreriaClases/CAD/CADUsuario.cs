﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibreriaOnline.EN;

namespace LibreriaOnline.CAD
{
    class CADUsuario
    {
        private string constring;
        public CADUsuario()
        {

        }
        public bool modificardatosUsuario(ENUsuario en)
        {
            return true;
        }
        public bool relatosUsuario(ENUsuario en)
        {
            return true;
        }
        public bool readrelatosUsuario(ENUsuario en)
        {
            return true;
        }
        public bool deleterelatosUsuario(ENUsuario en)
        {
            return true;
        }
        public bool venderUsuario(ENUsuario en)
        {
            return true;
        }
        public bool deletevenderUsuario(ENUsuario en)
        {
            return true;
        }
        public bool recomendarlibrosUsuario(ENUsuario en)
        {
            return true;
        }
        public bool criticaUsuario(ENUsuario en)
        {
            return true;
        }
        public bool readcriticaUsuario(ENUsuario en)
        {
            return true;
        }
        public bool deletecriticaUsuario(ENUsuario en)
        {
            return true;
        }
        public bool createUsuario(ENUsuario en)
        {
            return true;
        }
        public bool readUsuario(ENUsuario en)
        {
            return true;
        }
        public bool deleteUsuario(ENUsuario en)
        {
            return true;
        }
        public bool updateUsuario(ENUsuario en)
        {
            return true;
        }
    }
}
