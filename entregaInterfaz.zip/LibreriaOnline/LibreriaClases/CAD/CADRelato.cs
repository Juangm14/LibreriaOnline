﻿using LibreriaOnline.EN;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD {
    class CADRelato {

        public CADRelato() {
            //Establecemos conexion con la base de datos
        }

        public bool createRelato(ENRelato en) {
            return true;
        }
        public bool deleteRelato(ENRelato en) {
            return true;
        }
        public bool updateRelato(ENRelato en) {
            return true;
        }
        public bool leerRelato(ENRelato en) {
            return true;
        }
    }

}
