﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CADListaUsuario
{
	private string costring;

	public CADListaUsuario()
	{
	}

	public bool addListaUsuario(ENListaUsuario en)
	{

	}

	public bool removeListaUsuario(ENListaUsuario en)
	{

	}

	public bool updatePuntuacion()
	{
		
	}

	public bool readPuntuacion()
	{

	}
}
