﻿using LibreriaOnline.EN;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD
{
	public class CADRegistro
	{
		private String constring;
		public CADRegistro()
		{
		}
		public bool ExisteEmail(ENRegistro registro)
		{
			return true;
		}
		public bool ExisteNick(ENRegistro registro)
		{
			return true;
		}
		public bool Registrar(ENRegistro registro)
		{
			return true;
		}
		public bool ReadEmail(ENRegistro registro)
		{
			return true;
		}
		public bool ReadNick(ENRegistro registro)
		{
			return true;
		}

	}
}

