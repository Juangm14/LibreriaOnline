﻿using LibreriaOnline.EN;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaOnline.CAD {
    class CADCritica {
        public CADCritica() {
            //Establecemos conexion con la base de datos
        }

        public bool createCritica(ENCritica en) {
            return true;
        }
        public bool deleteCritica(ENCritica en) {
            return true;
        }
        public bool updateCritica(ENCritica en) {
            return true;
        }
        public bool leerCritica(ENCritica en) {
            return true;
        }
    }
}
}
