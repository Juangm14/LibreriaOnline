﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	public class CADColeccion
	{
		private string costring;

		public CADColeccion()
		{
		}

		public bool addColeccion(ENColeccion en)
		{

		}

		public bool removeColeccion(ENColeccion en)
		{

		}

		public bool updateColeccion()
		{
			
		}

		public bool readColeccion()
		{
			
		}
	}
}

